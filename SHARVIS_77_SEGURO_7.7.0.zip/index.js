import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
  jidNormalizedUser
} from "@whiskeysockets/baileys";
import pino from "pino";
import readline from "node:readline";
import fs from "node:fs";

const CONFIG = {
  name: "SHARVIS 77 SEGURO 👑",
  ownerName: "Leønide Antonio Lâmina",
  ownerNumber: "258852223969",
  ownerLocal: "852223969",
  botNumber: "25887269781",
  botLocal: "87269781",
  version: "7.7.0",
  prefix: "."
};

const AUTH_DIR = "./auth";
const logger = pino({ level: "silent" });

if (!fs.existsSync(AUTH_DIR)) fs.mkdirSync(AUTH_DIR, { recursive: true });

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function normalizeDigits(value = "") {
  return String(value).replace(/\D/g, "");
}

function isOwner(sender) {
  const s = normalizeDigits(sender.split("@")[0]);
  return s === CONFIG.ownerNumber || s === CONFIG.ownerLocal;
}

function textFromMessage(message) {
  if (!message) return "";
  const m =
    message.conversation ??
    message.extendedTextMessage?.text ??
    message.imageMessage?.caption ??
    message.videoMessage?.caption ??
    message.documentMessage?.caption ??
    "";
  return String(m).trim();
}

function unwrapMessage(message) {
  let m = message;
  while (m?.ephemeralMessage?.message) m = m.ephemeralMessage.message;
  while (m?.viewOnceMessage?.message) m = m.viewOnceMessage.message;
  return m;
}

function menuText() {
  return `╭════════════════════════════╮
│ SHARVIS 77 SEGURO 👑      │
╰════════════════════════════╯
📱 Versão: ${CONFIG.version}
👑 Dono: ${CONFIG.ownerName} - ${CONFIG.ownerLocal}
🤖 Bot: ${CONFIG.botLocal}

👤 Comandos de Membros (136)
💳 COMPRAS & MB (4): .compra, .comprovativo, .megas, .verificarsms
🧭 GERAIS (17): .adm, .ajuda, .criador, .dono, .help, .help-exemplos, .hora, .lembrete, .menu, .menu-interativo, .owner, .perfil, .ping, .pong, .profile, .time, .todos
🖼️ MÍDIA & STICKERS (31): .attp, .blur, .contrast, .contraste, .espelhar, .fig, .gray, .hd, .ia-fig, .ia-sticker, .invert, .inverter, .melhora, .melhorar, .muda-direcao, .mudar-direcao, .pixel, .pixel-art, .preto-e-branco, .rename, .renomear, .resetarfoto, .rip, .sticker, .to-hd, .toimage, .toimg, .ttp
🔎 BUSCA & UTILIDADES (16): .cep, .chave, .extrair, .g-search, .gera-link, .gerar-link, .get-lid, .google-search, .info-msg, .link, .metadados, .obter-metadados-mensagem, .raw, .raw-message, .to-link, .verificar
🧪 EXEMPLOS & TESTES (32): todos os comandos .enviar-*
📌 OUTROS (36): .ad, .antifoto, .antispam, .app, .ban-senha, .bolsonaro, .buttons, .cadeia, .calcula, .embaça, .embaçar, .f, .f-quote, .fk, .fq, .getlid, .lid, .linkgrupo, .list, .m-pesa, .menubot, .meu-lid, .mirror, .mpesa, .pagamento, .payment, .pb, .px, .rec, .rn, .s, .tempo, .ti, .up, .upload, .uptime

🛡️ Comandos de Admin (138)
💰 VENDAS & FINANCEIRO (11): .alugar (SÓ DONO), .bot, .depositar, .faltacompra, .picos, .restanas, .semcompra, .setmegas, .telefones, .venda-automatica, .venda-automativa
👥 GESTÃO DE GRUPO (32): .abre, .abre-grupo, .add, .ban, .promover, .rebaixar, etc.

⚙️ Sistema: Baileys 6.7.8
🔐 Sessão: ./auth
📡 Conexão: Pairing Code
👑 SHARVIS 77 SEGURO`;
}

function ownerText() {
  return `👑 DONO: ${CONFIG.ownerName}
📱 Número: ${CONFIG.ownerLocal}
🤖 BOT: ${CONFIG.botLocal}
🔥 SHARVIS 77 SEGURO`;
}

const aliases = new Map([
  ["dono", "dono"], ["criador", "dono"], ["owner", "dono"],
  ["help", "menu"], ["menubot", "menu"],
  ["ping", "ping"], ["pong", "pong"],
  ["hora", "hora"], ["time", "hora"],
  ["uptime", "uptime"], ["bot", "bot"],
  ["adm", "adm"], ["ajuda", "ajuda"],
  ["perfil", "perfil"], ["profile", "perfil"],
  ["menu-interativo", "menu-interativo"],
  ["alugar", "alugar"],
  ["pagamento", "pagamento"], ["payment", "pagamento"],
  ["mpesa", "mpesa"], ["m-pesa", "mpesa"],
  ["megas", "megas"], ["compra", "compra"],
  ["comprovativo", "comprovativo"], ["verificarsms", "verificarsms"],
  ["todos", "todos"], ["list", "list"],
  ["linkgrupo", "linkgrupo"]
]);

const startedAt = Date.now();

function unsupported(command) {
  return `⚙️ Comando .${command} reconhecido.\n\nEsta função está reservada na estrutura SHARVIS 77 SEGURO, mas a implementação específica ainda não foi adicionada.\n\nUse .menu para ver a estrutura completa.`;
}

async function handleCommand(sock, msg, command, args, sender, isGroup) {
  const key = aliases.get(command) ?? command;

  // REGRA CRÍTICA: somente o dono pode usar .alugar
  if (key === "alugar" && !isOwner(sender)) {
    await sock.sendMessage(msg.key.remoteJid, {
      text: "❌ Este comando é apenas para o dono Leønide Antonio Lâmina"
    });
    return;
  }

  switch (key) {
    case "menu":
      await sock.sendMessage(msg.key.remoteJid, { text: menuText() });
      break;

    case "dono":
      await sock.sendMessage(msg.key.remoteJid, { text: ownerText() });
      break;

    case "ping":
      await sock.sendMessage(msg.key.remoteJid, { text: "🏓 Pong!\n⚡ SHARVIS 77 SEGURO ONLINE" });
      break;

    case "pong":
      await sock.sendMessage(msg.key.remoteJid, { text: "🏓 Ping!\n⚡ SHARVIS 77 SEGURO ONLINE" });
      break;

    case "hora":
      await sock.sendMessage(msg.key.remoteJid, {
        text: `🕒 Hora do servidor: ${new Date().toLocaleString("pt-PT", {
          timeZone: "Africa/Maputo"
        })}`
      });
      break;

    case "uptime": {
      const seconds = Math.floor((Date.now() - startedAt) / 1000);
      const h = Math.floor(seconds / 3600);
      const m = Math.floor((seconds % 3600) / 60);
      const s = seconds % 60;
      await sock.sendMessage(msg.key.remoteJid, {
        text: `⏱️ Uptime: ${h}h ${m}m ${s}s\n🔥 ${CONFIG.name}`
      });
      break;
    }

    case "bot":
      await sock.sendMessage(msg.key.remoteJid, {
        text: `🤖 ${CONFIG.name}\n📱 Versão: ${CONFIG.version}\n📞 Bot: ${CONFIG.botLocal}\n👑 Dono: ${CONFIG.ownerName}`
      });
      break;

    case "adm":
      await sock.sendMessage(msg.key.remoteJid, {
        text: isGroup
          ? "🛡️ Comandos de administração disponíveis na estrutura SHARVIS 77 SEGURO."
          : "⚠️ Este comando foi pensado para grupos."
      });
      break;

    case "ajuda":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "💡 Use .menu para ver os comandos. Use .dono para ver os dados do proprietário."
      });
      break;

    case "perfil":
      await sock.sendMessage(msg.key.remoteJid, {
        text: `👤 Perfil\n📱 ${sender.split("@")[0]}\n👑 Dono: ${isOwner(sender) ? "SIM" : "NÃO"}`
      });
      break;

    case "menu-interativo":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "👑 SHARVIS 77 SEGURO\n\n1️⃣ .menu\n2️⃣ .dono\n3️⃣ .ping\n4️⃣ .alugar (somente dono)"
      });
      break;

    case "alugar":
      await sock.sendMessage(msg.key.remoteJid, {
        text: `👑 PAINEL DE ALUGUEL — SHARVIS 77 SEGURO\n\nDono autorizado: ${CONFIG.ownerName}\nNúmero: ${CONFIG.ownerLocal}\n\n⚙️ Módulo de aluguel iniciado.\nAdicione aqui a sua tabela/preços quando quiser.`
      });
      break;

    case "pagamento":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "💳 PAGAMENTO - SHARVIS 77 SEGURO\n\nEnvie o comprovativo e o número do pacote para o responsável."
      });
      break;

    case "mpesa":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "💰 M-PESA\n\nO módulo está preparado para receber os dados de pagamento configurados pelo proprietário."
      });
      break;

    case "megas":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "📶 MEGAS\n\nMódulo preparado. Configure os seus pacotes e preços no código antes de vender automaticamente."
      });
      break;

    case "compra":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "🛒 COMPRAS\n\nMódulo de compras SHARVIS 77 SEGURO."
      });
      break;

    case "comprovativo":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "🧾 Envie o comprovativo da compra neste chat."
      });
      break;

    case "verificarsms":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "📩 Verificação de SMS: módulo reservado para integração específica."
      });
      break;

    case "todos":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "📢 Comando recebido. Evite mensagens repetitivas para não gerar spam."
      });
      break;

    case "list":
      await sock.sendMessage(msg.key.remoteJid, {
        text: "📋 Use .menu para consultar a estrutura de comandos."
      });
      break;

    case "linkgrupo":
      if (!isGroup) {
        await sock.sendMessage(msg.key.remoteJid, { text: "⚠️ Este comando só funciona em grupos." });
        break;
      }
      try {
        const code = await sock.groupInviteCode(msg.key.remoteJid);
        await sock.sendMessage(msg.key.remoteJid, {
          text: `🔗 Link do grupo:\nhttps://chat.whatsapp.com/${code}`
        });
      } catch {
        await sock.sendMessage(msg.key.remoteJid, {
          text: "❌ Não foi possível obter o link deste grupo."
        });
      }
      break;

    default:
      await sock.sendMessage(msg.key.remoteJid, { text: unsupported(command) });
  }
}

async function requestPairingCode(sock) {
  if (sock.authState?.creds?.registered) return;

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  const ask = q => new Promise(resolve => rl.question(q, resolve));

  try {
    let number = await ask(`\n📱 Digite o número do WhatsApp do BOT (ex.: ${CONFIG.botLocal}): `);
    number = normalizeDigits(number);

    if (number.startsWith("258")) number = number.slice(3);
    if (number !== CONFIG.botLocal) {
      console.log(`⚠️ Número informado: ${number}`);
      console.log(`ℹ️ O projeto está configurado para ${CONFIG.botLocal}.`);
    }

    await sleep(1500);
    const code = await sock.requestPairingCode(number);
    console.log("\n╔══════════════════════════════════╗");
    console.log(`║ 🔐 PAIRING CODE: ${code}`);
    console.log("╚══════════════════════════════════╝");
    console.log("No WhatsApp: Dispositivos associados → Associar dispositivo → Associar com número de telefone.");
    console.log("Digite o código mostrado acima.\n");
  } finally {
    rl.close();
  }
}

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    printQRInTerminal: false,
    browser: Browsers.ubuntu("SHARVIS 77 SEGURO"),
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: false,
    syncFullHistory: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "connecting") {
      console.log("🔄 SHARVIS 77 conectando...");
    }

    if (connection === "open") {
      console.log(`SHARVIS 77 ONLINE - Dono: Leønide 852223969 - Bot: 87269781`);
      console.log("👑 SHARVIS 77 SEGURO — conexão estabelecida.");
    }

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      console.log(`❌ Conexão encerrada. Código: ${statusCode ?? "desconhecido"}`);

      if (shouldReconnect) {
        console.log("🔄 Reconectando...");
        await sleep(3000);
        startBot().catch(err => console.error("Erro ao reiniciar:", err));
      } else {
        console.log("🔐 Sessão encerrada. Apague ./auth e faça novo Pairing Code.");
      }
    }
  });

  if (!state.creds.registered) {
    await requestPairingCode(sock);
  }

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages?.[0];
    if (!msg?.message || msg.key.fromMe) return;

    try {
      const remoteJid = msg.key.remoteJid;
      if (!remoteJid) return;

      const sender = jidNormalizedUser(msg.key.participant || remoteJid);
      const raw = textFromMessage(unwrapMessage(msg.message));

      if (!raw.startsWith(CONFIG.prefix)) return;

      const parts = raw.slice(CONFIG.prefix.length).trim().split(/\s+/);
      const command = (parts.shift() || "").toLowerCase();
      const args = parts;

      if (!command) return;

      await handleCommand(
        sock,
        msg,
        command,
        args,
        sender,
        remoteJid.endsWith("@g.us")
      );
    } catch (err) {
      console.error("Erro ao processar mensagem:", err);
    }
  });
}

process.on("uncaughtException", err => {
  console.error("⚠️ Erro não tratado:", err);
});

process.on("unhandledRejection", err => {
  console.error("⚠️ Promise rejeitada:", err);
});

startBot().catch(err => {
  console.error("❌ Falha ao iniciar SHARVIS 77:", err);
  process.exit(1);
});
