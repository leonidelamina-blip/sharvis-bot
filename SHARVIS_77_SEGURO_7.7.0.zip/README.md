# SHARVIS 77 SEGURO 👑 — 7.7.0

## Requisitos
- Node.js 20+
- npm
- Uma conta WhatsApp para o número do bot

## Instalação

```bash
npm install
npm start
```

Na primeira execução, o programa pede o número do bot e mostra um Pairing Code.

No WhatsApp:
1. Definições/Configurações
2. Dispositivos associados
3. Associar dispositivo
4. Associar com número de telefone
5. Introduza o código mostrado pelo SHARVIS

A sessão fica em `./auth`.

## Comandos implementados
- `.menu` / `.help`
- `.dono` / `.criador` / `.owner`
- `.ping` / `.pong`
- `.hora` / `.time`
- `.uptime`
- `.bot`
- `.adm`
- `.ajuda`
- `.perfil` / `.profile`
- `.menu-interativo`
- `.alugar` — somente dono
- `.pagamento` / `.payment`
- `.mpesa` / `.m-pesa`
- `.megas`
- `.compra`
- `.comprovativo`
- `.verificarsms`
- `.todos`
- `.list`
- `.linkgrupo`

Os demais nomes apresentados no menu ficam registrados como estrutura e respondem com aviso de função ainda não implementada. Não são inventadas integrações externas.

## Regra crítica do proprietário

O `.alugar` só aceita o proprietário configurado:
`258852223969@s.whatsapp.net`

Qualquer outro remetente recebe:
`❌ Este comando é apenas para o dono Leønide Antonio Lâmina`

## Observação

O projeto não contém sistema de spam, disparo em massa ou automação de mensagens para listas. A ligação ao WhatsApp depende da disponibilidade e compatibilidade da versão da biblioteca utilizada.
